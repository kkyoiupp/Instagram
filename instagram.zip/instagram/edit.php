<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="icon" href="images/logo3.png">
    <title>Edit | Manis Kopi</title>
</head>
<body>
    <div class="container">
    <center><h1>Edit postingan</h1></center>
    <a href="index.php"><button class="btn btn-outline-secondary">Back to Home</button></a><br><br>

    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="gambar_lama" value="<?= $post['gambar'] ?>">
        
        <label for="">Gambar</label>
        <input type="file" name="gambar" id="" class="form-control" value="<?= $post['gambar'] ?>" ><br><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption'] ?>"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>"><br>
        <br>
        <input type="submit" button class="btn btn-secondary" value="Update" name="update"></button>
    </form>
</body>
</html>

<?php } ?>