<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Login | Manis Kopi</title>
</head>
<body>
    <form action="proses_login.php" method="post">
    <div class="box">
        <div class="container">
            <div class="top-header">
               <center> <img src="images/logo3.png "width="75" height="75"> </center>
                <header>Login</header><br><br>
            </div>
            <div class="input-field">
                <input type="text" class="form-control" name="input" placeholder="username" required>
                <i class="bx bx-user"></i>
                <br>
            </div>
            <div class="input-field">
                <input type="password" class="form-control" name="input" placeholder="password" required>
                <i class="bx bx-lock-alt"></i>
                <br><br>
            </div>
            <div class="input-field">
            <button class="btn btn-outline-light" value="Login">Login</button>
            </div>
            <div class="bottom">
                <div class="left">
                    <input type="checkbox" id="check">
                    <label for="check">Remember Me</label>
                </div>
                <div class="right">
                    <label><a href="#">Forgot password?</a></label>
                </div>
            </div>
        </div>
    </div>
</form>
</body>
</html>